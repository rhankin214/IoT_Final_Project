const FUNCTION_URL = "https://iot-ingest-func-henry-andzetf6gxafbef0.eastus2-01.azurewebsites.net/api/GetTelemetryRange?code=uF7AJEZHDC78eRcxJIUYcp3SUd2D4BQ1fllqqJKSn2kMAzFuzUvV6w==";

let tempChart, humidityChart, pressureChart, airChart;

async function loadData() {
    try {
        const res = await fetch(FUNCTION_URL);
        if (!res.ok) {
            console.error('Failed to fetch data:', res.status);
            document.querySelector('p').textContent = `Error loading data (${res.status}). Retrying in 30 seconds...`;
            return;
        }
        const data = await res.json();

        // Sort oldest → newest
        data.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

        // Downsample if very large (5000+ points down to 500 for performance)
        const maxPoints = 500;
        const step = Math.ceil(data.length / maxPoints);
        const sampled = data.filter((_, i) => i % step === 0);
        
        console.log(`Loaded ${data.length} points, displaying ${sampled.length} after downsampling`);

        const temp = sampled.map(d => ({ x: new Date(d.timestamp), y: d.temperature }));
        const humidity = sampled.map(d => ({ x: new Date(d.timestamp), y: d.humidity }));
        const pressure = sampled.map(d => ({ x: new Date(d.timestamp), y: d.pressure }));
        const air = sampled.map(d => ({ x: new Date(d.timestamp), y: d["air quality"] }));

        drawCharts(temp, humidity, pressure, air);
        const lastUpdate = new Date().toLocaleTimeString();
        document.querySelector('p').textContent = `Auto-refreshing every 30 seconds (Last update: ${lastUpdate} - ${data.length} data points)`;
    } catch (error) {
        console.error('Error loading data:', error);
        document.querySelector('p').textContent = 'Error loading data. Retrying in 30 seconds...';
    }
}

function drawCharts(temp, humidity, pressure, air) {
    // Get the actual data range for proper scaling
    const allTimes = temp.map(d => d.x.getTime());
    const minTime = Math.min(...allTimes);
    const maxTime = Math.max(...allTimes);
    
    const options = {
        responsive: true,
        maintainAspectRatio: false,
        parsing: false,
        scales: {
            x: { 
                type: "time",
                min: minTime,
                max: maxTime,
                time: { 
                    tooltipFormat: "MMM d, HH:mm",
                    displayFormats: {
                        hour: 'MMM d, HH:mm',
                        day: 'MMM d'
                    }
                },
                ticks: {
                    autoSkip: true,
                    maxRotation: 45,
                    minRotation: 45
                }
            },
            y: {
                beginAtZero: false
            }
        },
        plugins: {
            zoom: {
                zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: "x" },
                pan: { enabled: true, mode: "x" }
            }
        }
    };

    if (tempChart) tempChart.destroy();
    if (humidityChart) humidityChart.destroy();
    if (pressureChart) pressureChart.destroy();
    if (airChart) airChart.destroy();

    tempChart = new Chart(document.getElementById("tempChart"), {
        type: "line",
        data: { datasets: [{ label: "Temperature (°C)", borderColor: "red", data: temp }] },
        options
    });

    humidityChart = new Chart(document.getElementById("humidityChart"), {
        type: "line",
        data: { datasets: [{ label: "Humidity (%)", borderColor: "blue", data: humidity }] },
        options
    });

    pressureChart = new Chart(document.getElementById("pressureChart"), {
        type: "line",
        data: { datasets: [{ label: "Pressure (Pa)", borderColor: "green", data: pressure }] },
        options
    });

    airChart = new Chart(document.getElementById("airChart"), {
        type: "line",
        data: { datasets: [{ label: "Air Quality", borderColor: "purple", data: air }] },
        options
    });
}

loadData();
setInterval(loadData, 30_000);

