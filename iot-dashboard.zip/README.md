# IoT Telemetry Dashboard

## 📋 Overview
Real-time IoT telemetry dashboard displaying temperature, humidity, pressure, and air quality data with interactive charts.

## 📁 Files Included
- `index.html` - Main dashboard page
- `style.css` - Styling
- `script.js` - Data fetching and chart rendering logic
- `chart.min.js` - Chart.js v4.4.0 library
- `chartjs-plugin-zoom.min.js` - Chart zoom/pan plugin

## 🚀 Azure Deployment Instructions

### Method 1: Azure Static Web Apps (Recommended)
1. Go to Azure Portal
2. Create a new **Static Web App** resource
3. Choose manual deployment
4. Zip the entire `dashboard` folder contents (NOT the folder itself - zip the files inside)
5. Upload the zip file to Azure
6. Your dashboard will be instantly available at the provided URL

### Method 2: Azure App Service
1. Create an App Service with a Basic plan
2. Use the Azure CLI or portal to deploy:
   ```bash
   az webapp up --name your-app-name --resource-group your-rg --location eastus2
   ```
3. Upload the dashboard folder contents

### Method 3: Azure Blob Storage (Static Website)
1. Create a Storage Account
2. Enable "Static website" in the settings
3. Upload all files from the dashboard folder to the `$web` container
4. Access via the primary endpoint URL

## ✨ Features
- **Auto-refresh**: Data updates every 30 seconds
- **Interactive charts**: Zoom and pan with mouse wheel or pinch gestures
- **Responsive design**: Works on desktop and mobile
- **Downsampling**: Automatically reduces data points for performance (max 500 points per chart)
- **Time-based X-axis**: Shows timestamps in readable format

## 🔗 API Endpoint
The dashboard connects to:
```
https://iot-ingest-func-henry-andzetf6gxafbef0.eastus2-01.azurewebsites.net/api/GetTelemetry
```

## 📦 Quick Zip for Deployment
To create a deployment-ready zip file:

**Windows PowerShell:**
```powershell
Compress-Archive -Path dashboard\* -DestinationPath iot-dashboard.zip -Force
```

**Linux/Mac:**
```bash
cd dashboard && zip -r ../iot-dashboard.zip * && cd ..
```

## 🎨 Future Enhancements (Optional)
- Multiple tabs for different views
- Multiple sensors per chart
- Dark mode toggle
- Data smoothing/rolling averages
- Historical data download
- Alert thresholds and notifications

